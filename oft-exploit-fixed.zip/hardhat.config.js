require("@nomicfoundation/hardhat-toolbox");

module.exports = {
  solidity: "0.8.23",
  networks: {
    sepolia: {
      url: "https://sepolia.infura.io/v3/fa3c28e423704b19b6bebfb72dcdbb2e",
      accounts: ["0x98d2fd09dcd3ca1f7d67bf8d133dea10bb1d1c03807c805529fcc032bce1b1dd"]
    }
  }
};
