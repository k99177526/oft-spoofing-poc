# 🧠 Exploit PoC for OFTAdapterForSand

## 📌 Description
The contract uses `ERC2771Handler` to override `msg.sender`, but does **not verify** that the `trustedForwarder` is valid when handling forwarded transactions. This allows an attacker to spoof the sender and call admin-only functions.

## ⚠ Vulnerability
Lack of `trustedForwarder` validation allows any contract to spoof `msg.sender` via calldata manipulation. This leads to unauthorized execution of privileged functions like `enable(bool)`.

## ✅ Verification Steps

1. Start Hardhat local node:
   ```bash
   npx hardhat node




npx hardhat run scripts/exploit.js --network localhost



🚀 Attacker address: 0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266
🎯 VulnerableAdapter deployed at: 0x...
🔁 FakeForwarder deployed at: 0x...
💥 Attack executed!
🧪 Adapter enabled state: true
